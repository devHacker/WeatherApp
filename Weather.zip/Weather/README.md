# Weather
## Requirements:
* iOS 11.0+
* Xcode 9.4.1
* Swift 4.1

## Compatibility
This demo is expected to be run using Swift 4.1 and Xcode 9.4.x.

## Notices:
Implement an iOS native app using Swift 4.1 to demonstrate weather information. The current version is working with Xcode Version Xcode 9.1

## About:
* The Weather application provides weather updates for top metro cities of india with a search option for city 
* The Application also provides weather updates and forecast for next 5 days for current location with graphical representation for temperature of city.
* Following are the things provided by application.
    a) Weather updates for metro cities i.e (Temperature(High/Low), Humidity, WindSpeed, Visibility, Sunrise, Sunset).
    b) Weather update for current city and forecasted weather for next 9 days.
    c) Splash/Sign-in Screen
    d) Integration for High Charts SDK to show graphical representation of weather
    e) City/town search for weather update.


## TechStack:
 * Below is the tech stack used for development of tech stack.
   1) Design Pattern : MVVM, singletion, delegate design Pattern 
   2) Unit Test cases: Unit test cases had been written using XCUnit Test cases.
   3) Language : Objective-C/ Swift 
   4) Third Party SDK : Alamofire, Highcharts, SVProgressHUD, SwiftLint

## Project Structure 
* Folder Structure :
      a) AppDelegare
      b) Models
      c) ViewModel
      d) ViewControllers
      e) Views
      f) Storyboards
      g) APIHandler
      h) Service
      i) Util
      j) Helper
      k) Extension
      l) Resources
      m) Constants
      n) WeatherTests
      o) WeatherUITests
      p) Pods
      
## Login Cred:
    username : prateekarora91@gmail.com
    password : prateek@123


