//
//  MockFileManagerHandler.swift
//  WeatherTests
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import Foundation
@testable import Weather

class MockFileManagerHandler: FileManagerHandlerProtocol {
    var cityData: Data?

    func load<T>(resource: FileManagerResource<T>, completion: @escaping (T?) -> Void) {
        if let data = cityData {
            completion(resource.parse(data))
        } else {
            completion(nil)
        }
    }
}
