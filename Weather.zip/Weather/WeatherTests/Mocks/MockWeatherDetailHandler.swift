//
//  MockWeatherDetailHandler.swift
//  WeatherTests
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import Foundation
@testable import Weather

class MockWeatherDetailHandler: WeatherDetailHandlerProtocol {
    var weatherData: [[DetailModel]]? = [[DetailModel]]()

    func fetchWeatherInfo(withWeatherInfo data: WeatherInformation, completion: @escaping ((Result<[[DetailModel]], ErrorResult>) -> Void)) {
        if let result = weatherData {
            completion(.success(result))
        } else {
            completion(.failure(.parser(string: "Error while parsing json data")))
        }
    }
}
