//
//  MockWebService.swift
//  WeatherTests
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import Foundation
@testable import Weather

class MockWebService: WebServiceProtocol {
    var weatherData: Data?

    func load<T>(resource: Resource<T>, completion: @escaping (T?) -> Void) {
        if let data = weatherData {
            completion(resource.parse(data))
        } else {
            completion(nil)
        }
    }
}
