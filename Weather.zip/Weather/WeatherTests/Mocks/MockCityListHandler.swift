//
//  MockCityListHandler.swift
//  WeatherTests
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import Foundation
@testable import Weather

class MockCityListHandler: CityListHandlerProtocol {
    var cityListData: [CityListModel]? = [CityListModel]()

    func fetchCityInfo(withfileName fileName: String, completion: @escaping ((Result<[CityListModel], ErrorResult>) -> Void)) {
        if let result = cityListData {
            completion(.success(result))
        } else {
            completion(.failure(.parser(string: "Error while parsing json data")))
        }
    }
}
