//
//  AddCitiesCell.swift
//  Weather
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import UIKit

class AddCitiesCell: UITableViewCell {
    @IBOutlet weak var labelCityName: UILabel!
    @IBOutlet weak var labelCityId: UILabel!

    var addCitiesModel: CityListModel? {
        didSet {
            guard let data = addCitiesModel else {
                return
            }
            labelCityName.text = data.name
            labelCityId.text = "\(data.id ?? 0)"
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
