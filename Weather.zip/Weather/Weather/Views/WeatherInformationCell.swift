//
//  WeatherInformationCell.swift
//  Weather
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import UIKit

class WeatherInformationCell: UITableViewCell {
    @IBOutlet weak var labelCityName: UILabel!
    @IBOutlet weak var labelCityTemperature: UILabel!

    var WeatherModel: WeatherInformation? {
        didSet {
            guard let data = WeatherModel else {
                return
            }
            labelCityName.text = data.name
            labelCityTemperature.text = "\(data.main?.temp ?? 0) °C"
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
