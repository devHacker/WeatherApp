//
//  WeatherListViewModelProtocol.swift
//  Weather
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import Foundation

protocol WeatherListViewModelProtocol {
    var weatherList: Dynamic<[WeatherInformation]> { get }
    var onErrorHandling: ((ErrorResult?) -> Void)? { get set }

    var isFinished: Dynamic<Bool> { get }
    func pullToRefresh()
    func fetchWeatherInfo(byCity city: CityListModel)

}
