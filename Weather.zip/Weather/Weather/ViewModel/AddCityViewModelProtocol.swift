//
//  AddCityViewModelProtocol.swift
//  Weather
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import Foundation

protocol AddCityViewModelProtocol {
    var cityListModel: Dynamic<[CityListModel]> { get }
    var onErrorHandling: ((ErrorResult?) -> Void)? { get set }
    var isFinished: Dynamic<Bool> { get }
}
