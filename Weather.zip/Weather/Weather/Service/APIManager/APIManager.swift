//
//  APIManager.swift
//  Weather
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import Foundation

enum Method: String {
    case bangaloreId = "1277333"
    case delhiId = "4321929"
    case hyderabadId = "1269843"
}

struct APIManager {
    private static let baseURLString = "http://api.openweathermap.org/data/2.5/"
    private static let apiKey = "5a230a39a381b73ad15ca01075d63117"
    private static let weatherUnit = "weather?"
    private static let groupUnit = "group?"

    private static let Metric = "metric"

    static var bangaloreURL: URL {
        return weatherAPIURL(method: .bangaloreId)
    }

    static var delhiURL: URL {
        return weatherAPIURL(method: .delhiId)
    }

    static var hyderbadURL: URL {
        return weatherAPIURL(method: .hyderabadId)
    }

    // MARK: - General Methods
    private static func weatherAPIURL(method: Method) -> URL {
        let weatherInfoUrl =  baseURLString + "id=\(method.rawValue)&units=\(weatherUnit)&APPID=\(apiKey)"
        let finalURL = URL(string: weatherInfoUrl)!
        return finalURL
    }
    public static func weatherAPIURL(_ cityID: String) -> URL {
        let weatherInfoUrl =  baseURLString + weatherUnit + "id=\(cityID)&units=\(Metric)&APPID=\(apiKey)"
        let finalURL = URL(string: weatherInfoUrl)!
        return finalURL
    }
   // https://samples.openweathermap.org/data/2.5/group?id=524901,703448,2643743&units=metric&appid=b6907d289e10d714a6e88b30761fae22
    public static func weatherGroupAPIURL(_ cityID: String) -> URL {
        let weatherInfoUrl =  baseURLString + groupUnit + "id=\(cityID)&units=\(Metric)&APPID=\(apiKey)"
        let finalURL = URL(string: weatherInfoUrl)!
        return finalURL
    }
}
