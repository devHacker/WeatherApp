//
//  LoginViewController.swift
//  Weather
//
//  Created by Arora, Prateek on 01/01/21.
//  Copyright © 2021 NischalHada. All rights reserved.
//

import UIKit
import LocalAuthentication
class LoginViewController: UIViewController {

    @IBOutlet weak var imgAuthenticate: UIImageView!
      let context = LAContext()
      var strAlertMessage = String()
      var error: NSError?
    @IBOutlet var txtfieldEmail: UITextField!
    
    @IBOutlet var loginButton: UIButton!
    
    @IBOutlet var txtFieldPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        if UserDefaults.standard.bool(forKey: "isUserLoggedIn") ==  true {
//            let homeVc  = self.storyboard?.instantiateViewController(withIdentifier: "WeatherTableViewController") as! WeatherTableViewController
//            self.navigationController?.pushViewController(homeVc, animated: true)
//        }
        // Do any additional setup after loading the view.
    }
    
    @IBAction func loginButton(_ sender: Any) {
        if txtfieldEmail.text == "prateekarora91@gmail.com" || txtFieldPassword.text == "prateek@123" {
            UserDefaults.standard.set(true, forKey: "isUserLoggedIn")
            let homeVc  = self.storyboard?.instantiateViewController(withIdentifier: "WeatherTableViewController") as! WeatherTableViewController
            self.navigationController?.pushViewController(homeVc, animated: true)
        } else {
            let alert = UIAlertController(title: "Wrong Credentials", message: "Enter the correct username and password!!", preferredStyle: .alert)

            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))

            self.present(alert, animated: true)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
