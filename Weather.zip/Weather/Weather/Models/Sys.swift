//
//  Sys.swift
//  Weather
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import Foundation

struct Sys: Codable {
    var sunset: Int?
    var sunrise: Int?
    var message: Double?
    var id: Int?
    var type: Int?
    var country: String?
}
