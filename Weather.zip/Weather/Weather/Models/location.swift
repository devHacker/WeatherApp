//
//  location.swift
//  weatherApp
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import CoreLocation

class location {
    static var sharedInstance = location()
    private init(){}
    
    var latitude: Double!
    var longitude: Double!
    
}
