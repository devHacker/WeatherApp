//
//  CityListModel.swift
//  Weather
//
//  Created by Arora, Prateek on 2/01/21.
//  Copyright © 2021 PrateekArora. All rights reserved.
//

import Foundation

struct CityListModel: Codable {
    let id: Int?
    let name: String?
    let coord: Coord?
    let country: String?
}

extension CityListModel {
    static var empty: CityListModel {
        return CityListModel(id: nil, name: nil, coord: nil, country: nil)
    }
}
